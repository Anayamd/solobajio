from django.apps import AppConfig


class SpvConfig(AppConfig):
    name = 'spv'
